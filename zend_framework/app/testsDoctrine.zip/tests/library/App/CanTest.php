<?php

// class CanTest extends Controller_Test_Case {

// 	public function testCanDoUnitTest() {
// 		$this->assertTrue(true);
// 	}

// }