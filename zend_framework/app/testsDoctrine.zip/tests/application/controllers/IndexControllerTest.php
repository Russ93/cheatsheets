<?php
require_once 'Zend/Application.php';

abstract class ControllerTestCase extends Zend_Test_PHPUnit_ControllerTestCase {

	// public function appBootstrap() {
	// 	$this->frontController
	// 		 ->registerPlugin(new Bugapp_Plugin_Initialize('testing'));
	// }

	public function testCallWithoutActionShouldPullFromIndexAction() {
		$this->dispatch('/');
		$this->assertController('index');
		$this->assertAction('index');
	}

	public function testIndexActionShouldContainLoginForm() {
		$this->dispatch('/');
		$this->assertAction('index');
		// $this->assertQueryCount('form#loginForm', 1);
	}

	// public function testValidLoginShouldGoToProfilePage() {
	// 	$this->request->setMethod('POST')
	// 		  ->setPost([
	// 			  'testname' => 'foobar',
	// 			  'password' => 'foobar'
	// 		  ]);
	// 	$this->dispatch('/test/login');
	// 	$this->assertRedirectTo('/test/view');

	// 	$this->resetRequest()
	// 		 ->resetResponse();

	// 	$this->request->setMethod('GET')
	// 		 ->setPost([]);
	// 	$this->dispatch('/test/view');
	// 	$this->assertRoute('default');
	// 	$this->assertModule('default');
	// 	$this->assertController('test');
	// 	$this->assertAction('view');
	// 	$this->assertNotRedirect();
	// 	$this->assertQuery('dl');
	// 	$this->assertQueryContentContains('h2', 'test: foobar');
	// }
}